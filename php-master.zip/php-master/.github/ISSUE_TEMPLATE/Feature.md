---
name: Feature request 🚀
about: I would appreciate new feature or something!
---

# Feature Request

<!-- Describe it -->
