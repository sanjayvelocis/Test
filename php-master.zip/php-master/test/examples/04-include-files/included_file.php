<?php

echo 'included:RANDOMNESS_PLACEHOLDER';
