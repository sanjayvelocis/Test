<?php
print($_ENV['RANDOMNESS_ENV_VAR'] . ':env');
