<?php
print('cow:RANDOMNESS_PLACEHOLDER');
