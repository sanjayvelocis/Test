<?php
print('yoda:RANDOMNESS_PLACEHOLDER');
