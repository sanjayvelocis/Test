<?php

echo "Hello from subfolder!";
