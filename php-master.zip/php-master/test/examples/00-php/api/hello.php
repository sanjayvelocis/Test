<?php echo 'Hello from PHP on Now 2.0!';
