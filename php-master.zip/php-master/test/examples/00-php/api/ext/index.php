<?php
echo implode(',', get_loaded_extensions());
?>
