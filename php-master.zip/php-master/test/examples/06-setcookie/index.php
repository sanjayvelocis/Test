<?php
header('Content-Type: text/plain');
header('Content-Type: text/plain; charset=UTF-16');
setcookie('cookie1', 'cookie1value');
setcookie('cookie2', 'cookie2value');
