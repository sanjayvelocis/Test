<?php
var_dump(opcache_compile_file(__FILE__));
